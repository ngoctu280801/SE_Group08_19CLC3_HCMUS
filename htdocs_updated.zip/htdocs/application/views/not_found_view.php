<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>404 NOT FOUND</title>
</head>
<body>
	<h1>404 NOT FOUND</h1>
	<p>The URL you have accessed does not found</p>
</body>
</html>